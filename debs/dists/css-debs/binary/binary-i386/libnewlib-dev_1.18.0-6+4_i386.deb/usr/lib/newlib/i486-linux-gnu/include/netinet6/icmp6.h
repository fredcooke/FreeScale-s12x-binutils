/*	$FreeBSD: src/sys/netinet6/icmp6.h,v 1.6 2000/07/04 16:35:09 itojun Exp $	*/
/*	$KAME: icmp6.h,v 1.17 2000/06/11 17:23:40 jinmei Exp $	*/

#error "netinet6/icmp6.h is obsolete.  use netinet/icmp6.h"

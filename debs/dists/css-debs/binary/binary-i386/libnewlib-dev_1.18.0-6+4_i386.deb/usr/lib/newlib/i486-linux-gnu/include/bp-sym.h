#ifndef __BP_SYM_H__
#define __BP_SYM_H__

#define BP_SYM(NAME) NAME

#endif

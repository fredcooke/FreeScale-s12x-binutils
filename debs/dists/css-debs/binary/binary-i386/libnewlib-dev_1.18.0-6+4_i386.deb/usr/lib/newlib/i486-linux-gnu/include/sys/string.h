#ifndef _SYS_STRING_H
#define _SYS_STRING_H

#ifndef __STRICT_ANSI__
char    *_EXFUN(strsignal, (int __signo));
#endif

#endif /* _SYS_STRING_H */
